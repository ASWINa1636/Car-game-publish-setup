cat > README.md << 'EOF'
# cargame

Terminal car racing game.

- Run with: `car-game`
- Change controls from in-game menu.
EOF
